"""Shared Aegis platform contracts, versioned independently of application code."""

__version__ = "0.1.0"
