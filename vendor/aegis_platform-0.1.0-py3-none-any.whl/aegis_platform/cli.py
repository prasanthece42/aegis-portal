import argparse
import json
import sys
from pathlib import Path

from aegis_platform.catalog import load_catalog
from aegis_platform.contracts import CatalogEntry, DeploymentIntent, DesiredState


def main():
    parser = argparse.ArgumentParser(description="Validate reviewed Aegis application bindings")
    parser.add_argument("--catalog", type=Path, default=Path("catalog"))
    parser.add_argument("--policy", type=Path, default=Path("policies/catalog.json"))
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("validate")
    resolve = commands.add_parser("resolve")
    resolve.add_argument("--app", required=True)
    resolve.add_argument("--environment", choices=["dev", "staging", "prod"], required=True)
    diff = commands.add_parser("check-diff")
    diff.add_argument("--app", required=True)
    diff.add_argument("--environment", choices=["dev", "staging", "prod"], required=True)
    diff.add_argument("--release-tag", required=True)
    diff.add_argument("--paths", type=Path, required=True, help="JSON array of all changed paths")
    commands.add_parser("export-schemas").add_argument(
        "--output", type=Path, default=Path("schemas")
    )
    args = parser.parse_args()
    try:
        if args.command == "export-schemas":
            export_schemas(args.output)
            return
        catalog = load_catalog(args.catalog, args.policy)
        if args.command == "resolve":
            print(json.dumps(catalog.resolve(args.app, args.environment), indent=2))
        elif args.command == "check-diff":
            from aegis_platform.canonical import strict_json

            paths = strict_json(args.paths.read_bytes())
            if not isinstance(paths, list) or any(not isinstance(p, str) for p in paths):
                raise ValueError("Changed paths must be a complete JSON array of strings")
            catalog.check_delivery_paths(args.app, args.environment, args.release_tag, paths)
            print("PASS: delivery paths belong to the selected app/environment")
        else:
            print(
                f"PASS: {len(catalog.apps)} applications, {len(catalog.clusters)} enrolled clusters"
            )
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f"Catalog validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from None


def export_schemas(directory: Path):
    from aegis_platform.catalog import CatalogPolicy, Cluster
    from aegis_platform.contracts import RegistrationFields, RegistrationSubmission

    directory.mkdir(parents=True, exist_ok=True)
    for model, name in [
        (CatalogEntry, "catalog-entry"),
        (DeploymentIntent, "deployment-intent"),
        (DesiredState, "desired-state"),
        (CatalogPolicy, "catalog-policy"),
        (Cluster, "cluster-enrollment"),
        (RegistrationFields, "registration-fields"),
        (RegistrationSubmission, "registration-submission"),
    ]:
        schema = model.model_json_schema()
        schema["$schema"] = "https://json-schema.org/draft/2020-12/schema"
        (directory / f"{name}.v1.json").write_text(json.dumps(schema, indent=2) + "\n")
